package com.javacodegeeks.xuggler;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import com.xuggle.xuggler.Converter;

public class Transcoder {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String inputStream = "rtmp://194.219.97.78/live/streamLive3H.263";
		String outputStream = "rtmp://194.219.97.78/live/streamLive3H.264";

		String[] parameters = new String[] { "--acodec", "libfaac", "--vcodec",
				"libx264", "--vpreset",
				"/usr/local/xuggler/share/ffmpeg/libx264-ultrafast.ffpreset",
				inputStream, outputStream };

		Converter converter = new Converter();

		Options options = converter.defineOptions();

		CommandLine cmdLine;
		try {
			cmdLine = converter.parseOptions(options, parameters);
			converter.run(cmdLine);
			System.out.println("Finish!!!");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
